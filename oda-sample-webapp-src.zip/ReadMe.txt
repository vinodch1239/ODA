Follow the next steps to build ODA Drawings SDK for Java sample web application for vc10_amd64dll configuration:

1. Download and install: JDK 1.7 http://www.oracle.com/technetwork/java/javase/downloads

2. Download, install and configure MAVEN to be used from command line: http://maven.apache.org/download.cgi

3. Download latest build of ODA Software binaries and Teigha.JAVA. You will need the following modules:
3.1 ODA Kernel SDK
3.2 ODA Drawings SDK
3.3 ODA Drawings SDK for Java
https://www.opendesign.com/members/memberfiles
Content of all archives above must be extracted to ./Teigha.JAVA/exe/vc10_amd64dll folder

4. ODA Drawings SDK for Java Activation:
4.1 For Trial users: you have to activate your trial license for Teigha Drawings in ./Teigha.JAVA/exe/vc10_amd64dll directory following instructions at https://www.opendesign.com/free-trial#activating
4.2 For regular ODA members: generate OdActivationInfo.java at https://www.opendesign.com/members/activation and put it to ./activation/teigha

5. Run the following command in console:
   > mvn clean install

6. Download and install Apache Tomcat server: http://tomcat.apache.org/

7. Copy target/oda-sample-webapp.war under %TOMCAT_HOME%/webapps folder

Note: to run the web app, you must add the following value to PATH environment variable:
%TOMCAT_HOME%/webapps/oda-sample-webapp/WEB-INF/classes
To do this, add the following line to %TOMCAT_HOME%/catalina.bat after definition of CATALINA_HOME
set PATH=%CATALINA_HOME%/webapps/oda-sample-webapp/WEB-INF/classes;%PATH%

8. Create folder C:\TEMP

9. Start tomcat

10. Open URL http://localhost:8080/oda-sample-webapp in your browser

11. Upload a .dwg file and click "Convert" button
