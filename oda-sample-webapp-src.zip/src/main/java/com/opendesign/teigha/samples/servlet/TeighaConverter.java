/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2019, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Open Design Alliance software pursuant to a license 
//   agreement with Open Design Alliance.
//   Open Design Alliance Copyright (C) 2002-2019 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////
package com.opendesign.teigha.samples.servlet;

import com.opendesign.teigha.samples.java.BaseFileConverter;
import com.opendesign.teigha.samples.java.Converters;
import com.opendesign.teigha.samples.java.FileConverter;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TeighaConverter extends HttpServlet {

    private String outputFilePath;
    private String inputFilePath;
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    public void init() {
        // Get the file location where it would be stored.
        outputFilePath = getInitParameter("output-file-storage");
        inputFilePath = getInitParameter("input-file-storage");
        BaseFileConverter.init();
    }

    public void doPost(HttpServletRequest request,
                       HttpServletResponse response)
            throws ServletException, java.io.IOException {

        // Check that we have a file upload request
        boolean multipart = ServletFileUpload.isMultipartContent(request);

        if (!multipart)
            throw new ServletException("Invalid request");

        DiskFileItemFactory factory = new DiskFileItemFactory();
        int maxMemSize = 4 * 1024;
        factory.setSizeThreshold(maxMemSize);
        factory.setRepository(new File(System.getProperty("java.io.tmpdir")));

        ServletFileUpload upload = new ServletFileUpload(factory);
        int maxFileSize = 50 * 1024 * 1024;
        upload.setSizeMax(maxFileSize);

        try {

            List fileItems = upload.parseRequest(request);
            Map<String, String> requestParameters = new HashMap<String, String>();

            for (Object fileItem : fileItems) {
                FileItem fi = (FileItem) fileItem;
                if (fi.isFormField()) {
                    String key = fi.getFieldName();
                    String val = fi.getString();
                    requestParameters.put(key, val);
                }
            }


            for (Object fileItem : fileItems) {

                FileItem fi = (FileItem) fileItem;

                if (!fi.isFormField()) {


                    File temp = getFilePath(inputFilePath);
                    temp.getParentFile().mkdirs();
                    logger.info("Uploading file to {}", temp);
                    fi.write(temp);

                    File outFile = getFilePath(outputFilePath);
                    outFile.getParentFile().mkdirs();
                    String fileName = outFile.getCanonicalPath();

                    File outFilePdf = new File(fileName + ".pdf");
                    //File outFileBmp = new File(fileName + ".bmp");
                    File outFilePng = new File(fileName + ".png");

                    synchronized (this) {

                        FileConverter pdfConverter = getFileConverter("pdf");
                        logger.info("Converting file {} to {}", temp, outFilePdf);
                        pdfConverter.convertFile(temp, outFilePdf);

                        FileConverter pngConverter = getFileConverter("png");
                        logger.info("Converting file {} to {}", temp, outFilePng);
                        pngConverter.convertFile(temp, outFilePng);
                    }

                    String uuid = UUID.randomUUID().toString();

                    request.getSession(false).setAttribute(uuid + ".pdf", outFilePdf.getAbsolutePath());
                    request.getSession(false).setAttribute(uuid + ".png", outFilePng.getAbsolutePath());

                    response.sendRedirect(request.getContextPath() + "?result=" + uuid);

                    temp.delete();
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new ServletException("Can't process input file", ex);
        }
    }

    private File getFilePath(String parentFolder) throws IOException {
        Formatter f = new Formatter();
        Calendar c = Calendar.getInstance();
        f.format("%s/%d/%02d/%02d/%d.dwg", parentFolder, c.get(Calendar.YEAR), c.get(Calendar.MONTH)+1,
                c.get(Calendar.DAY_OF_MONTH), new Random().nextLong());
        return new File(f.toString());
    }

    private FileConverter getFileConverter(String outFormat) throws ServletException {
        FileConverter converter = Converters.getInstance().get(outFormat);
        if (null == converter)
            throw new ServletException("Incorrect output file format or required converter is not found: " + outFormat);
        return converter;
    }

    /**
     * @param outFormat
     * @return
     */
    private String outFormat(String outFormat) {
        if (outFormat == null || "null".equals(outFormat)) outFormat = "pdf";
        return outFormat;
    }

    /**
     * @param request
     * @param response
     * @throws ServletException
     * @throws java.io.IOException
     */
    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
            throws ServletException, java.io.IOException {

        String uuid = request.getParameter("result");
        String result = (String) request.getSession(false).getAttribute(uuid);

        if (result == null) {

            throw new ServletException("GET parameter 'result' is not set");

        } else {

            File file = new File(result);

            String outFormat = outFormat(request.getParameter("to"));
            FileConverter converter = getFileConverter(outFormat);

            String disposition = "inline; filename=\"" + uuid + "." + converter.getFileExtension() + "\"";
            response.setHeader("Content-disposition", disposition);

            response.setContentType(converter.getContentType());
            response.setContentLength((int) file.length());

            OutputStream outStream = response.getOutputStream();
            FileInputStream inStream = new FileInputStream(file);
            IOUtils.copy(inStream, outStream);

            inStream.close();
        }
    }
}
