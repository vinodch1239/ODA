/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2019, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Open Design Alliance software pursuant to a license 
//   agreement with Open Design Alliance.
//   Open Design Alliance Copyright (C) 2002-2019 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////
package com.opendesign.teigha.samples.java;

import com.opendesign.core.*;
import com.opendesign.td.OdDbDatabase;

import java.io.File;

public class DwgToPdfFileConverter extends BaseFileConverter {

    public void convertFile(File from, File to) throws FileConvertException {

        OdDbDatabase db = HostApp.readFile(from.getAbsolutePath());
        // PDF start
        PDFExportParams exportParams = new PDFExportParams();
        // added string props start
        exportParams.setTitle("TeighaConverter");
        exportParams.setAuthor("TeighaConverter");
        exportParams.setSubject("TeighaConverter");
        exportParams.setKeywords("TeighaConverter");
        exportParams.setCreator("TeighaConverter");
        exportParams.setProducer("TeighaConverter");
        // added string props stop
        exportParams.setVersion(PDFExportParams.PDFExportVersions.kPDFv1_5);
        //exportParams.setBAllViews(false);

        exportParams.setExportFlags(PDFExportParams.PDFExportFlags.kEmbededTTF |
                PDFExportParams.PDFExportFlags.kSHXTextAsGeometry |
                PDFExportParams.PDFExportFlags.kSimpleGeomOptimization |
                PDFExportParams.PDFExportFlags.kZoomToExtentsMode |
                PDFExportParams.PDFExportFlags.kEnableLayers |
                PDFExportParams.PDFExportFlags.kIncludeOffLayers |
                PDFExportParams.PDFExportFlags.kUseHLR |
                PDFExportParams.PDFExportFlags.kFlateCompression |
                PDFExportParams.PDFExportFlags.kASCIIHexEncoding);

        exportParams.setDatabase(db);
        long[] CurPalette = Globals.odcmAcadLightPalette();
        CurPalette[255] = 0x00ffffff;
        exportParams.setPalette(CurPalette);


        OdStreamBuf pdf_file = systemServices.createFile(to.getAbsolutePath(), FileAccessMode.kFileWrite, FileShareMode.kShareDenyNo, FileCreationDisposition.kCreateAlways);
        exportParams.setOutputStream(pdf_file);

        // set layout - it is possible to use actuve only
        OdStringArray layArr = exportParams.layouts();
        layArr.add(db.findActiveLayout(true));
        exportParams.setLayouts(layArr);

        OdGsPageParamsArray ppArr = exportParams.pageParams();
        long len = layArr.size();
        if (1 > layArr.size()) len = 1;
        ppArr.resize(len);
        exportParams.setPageParams(ppArr);
        PdfExportModule module = new PdfExportModule(OdRxModule.getCPtr(pdfModule), false); //= PdfExportModule.cast();
        OdPdfExport exporter = module.create();
        long errCode = exporter.exportPdfStr(exportParams, pdf_file);

        pdf_file.delete();
        exportParams.delete();

        if (errCode != 0) {
            throw new FileConvertException(exporter.exportPdfErrorCode(errCode));
        }

    }

    @Override
    public String getContentType() {
        return "application/pdf";
    }

    @Override
    public String getFileExtension() {
        return "pdf";
    }
}
