/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2019, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Open Design Alliance software pursuant to a license 
//   agreement with Open Design Alliance.
//   Open Design Alliance Copyright (C) 2002-2019 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////
package com.opendesign.teigha.samples.java;

import com.opendesign.core.*;
import com.opendesign.td.*;

import java.io.File;

public class DwgToBmpFileConverter extends BaseFileConverter {

    public void convertFile(File from, File to) throws FileConvertException {

        OdDbDatabase db = HostApp.readFile(from.getAbsolutePath());
        
        //////// BMP start second variant ///////
        OdEdCommandStack pCommands = Globals.odedRegCmds();
        String tmp = "WinOpenGL.txv" + "\nExtents\n\n" + "768\n1024\n\n255\n255\n255\n" + to.getAbsolutePath();
        
        ExStringIO strIO = ExStringIO.create(tmp);
        OdDbCommandContext pCon = ExDbCommandContext.createObject(strIO, db);
        OdGsModule pGs = OdGsModule.cast(Globals.odrxDynamicLinker().loadModule("TD_RasterExport"));			
        pCommands.executeCommand("bmpoutbg", pCon);
        //////// BMP finish second variant ///////

    }

    @Override
    public String getContentType() {
        return "image/bmp";
    }

    @Override
    public String getFileExtension() {
        return "bmp";
    }
}
